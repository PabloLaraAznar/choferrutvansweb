<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TravelHistoryController;
use App\Http\Controllers\RouteUnitScheduleController;

Route::get('/users', [UserController::class, 'index']);
Route::post('/users', [UserController::class, 'store']);
Route::post('/login', [UserController::class, 'login']);
Route::get('/recent-trips', [TravelHistoryController::class, 'getRecentTrips']);
Route::patch('/travel-history/{id}', [TravelHistoryController::class, 'updateTravelRating']);
Route::get('/route-unit-schedules', [RouteUnitScheduleController::class, 'getRouteUnitSchedules']);
Route::get('/user', [UserController::class, 'getUser']);
Route::patch('/user', [UserController::class, 'updateUser']);
Route::post('/user/upload-photo', [UserController::class, 'uploadPhoto']);
Route::get('/ping', function () {
    return response()->json([
        'status' => 'ok',
        'message' => 'API funcionando en Laravel 12 con api.php 🧠🔥'
    ]);
});