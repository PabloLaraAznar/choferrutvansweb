

<?php $__env->startSection('title', 'Ruta Unidad'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="m-0">
            <i class="fas fa-shipping-fast me-2 text-primary"></i> Gestión de Rutas por unidad
        </h1>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#modalCrearRutaUnidad">
        <i class="fas fa-plus-circle"></i> Crear nueva ruta unidad
    </button>

    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ruta</th>
                <th>Conductor</th>
                <th>Ubicación intermedia</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->id_route); ?></td>
                    <td><?php echo e($item->id_driver_unit); ?></td>
                    <td><?php echo e($item->intermediate_location_id); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td>
                        <a href="<?php echo e(route('ruta_unidad.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('ruta_unidad.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="modalCrearRutaUnidad" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="<?php echo e(route('ruta_unidad.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalLabel">Crear nueva Ruta Unidad</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="id_route">ID Ruta</label>
                            <input type="number" name="id_route" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="id_driver_unit">ID Conductor Unidad</label>
                            <input type="number" name="id_driver_unit" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="intermediate_location_id">ID Ubicación Intermedia</label>
                            <input type="number" name="intermediate_location_id" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="price">Precio</label>
                            <input type="number" step="0.01" name="price" class="form-control" required>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Guardar</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rutvans1\backend\resources\views/ruta_unidad/index.blade.php ENDPATH**/ ?>