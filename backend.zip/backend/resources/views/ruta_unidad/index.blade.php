@extends('adminlte::page')

@section('title', 'Ruta Unidad')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="m-0">
            <i class="fas fa-shipping-fast me-2 text-primary"></i> Gestión de Rutas por unidad
        </h1>
    </div>
@endsection

@section('content')
    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#modalCrearRutaUnidad">
        <i class="fas fa-plus-circle"></i> Crear nueva ruta unidad
    </button>

    {{-- Tabla --}}
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ruta</th>
                <th>Conductor</th>
                <th>Ubicación intermedia</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach($datos as $item)
                <tr>
                    <td>{{ $item->id }}</td>
                    <td>{{ $item->id_route }}</td>
                    <td>{{ $item->id_driver_unit }}</td>
                    <td>{{ $item->intermediate_location_id }}</td>
                    <td>{{ $item->price }}</td>
                    <td>
                        <a href="{{ route('ruta_unidad.edit', $item->id) }}" class="btn btn-sm btn-warning">Editar</a>
                        <form action="{{ route('ruta_unidad.destroy', $item->id) }}" method="POST" style="display:inline;">
                            @csrf @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="modalCrearRutaUnidad" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="{{ route('ruta_unidad.store') }}" method="POST">
                    @csrf
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalLabel">Crear nueva Ruta Unidad</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="id_route">ID Ruta</label>
                            <input type="number" name="id_route" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="id_driver_unit">ID Conductor Unidad</label>
                            <input type="number" name="id_driver_unit" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="intermediate_location_id">ID Ubicación Intermedia</label>
                            <input type="number" name="intermediate_location_id" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="price">Precio</label>
                            <input type="number" step="0.01" name="price" class="form-control" required>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Guardar</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('js')
    {{-- Bootstrap 4 JS (solo si no está cargado ya) --}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
@endsection
