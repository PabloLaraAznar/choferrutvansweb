@extends('layouts.app')

@section('content')
<h1>Editar Ruta Unidad</h1>

<form method="POST" action="{{ route('ruta_unidad.update', $rutaUnidad->id) }}">
    @csrf @method('PUT')
    <input type="text" name="id_route" value="{{ $rutaUnidad->id_route }}"><br>
    <input type="text" name="id_driver_unit" value="{{ $rutaUnidad->id_driver_unit }}"><br>
    <input type="text" name="intermediate_location_id" value="{{ $rutaUnidad->intermediate_location_id }}"><br>
    <input type="text" name="price" value="{{ $rutaUnidad->price }}"><br>
    <button type="submit">Actualizar</button>
</form>
@endsection
