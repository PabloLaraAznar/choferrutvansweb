<!-- Modal para Crear Ruta Unidad -->
<div class="modal fade" id="createRutaUnidadModal" tabindex="-1" aria-labelledby="createRutaUnidadModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form action="{{ route('ruta_unidad.store') }}" method="POST" class="needs-validation" novalidate autocomplete="off" id="createRutaUnidadForm">
            @csrf
            <div class="modal-content shadow-lg rounded-3">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title fw-bold" id="createRutaUnidadModalLabel">Crear Ruta Unidad</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>

                <div class="modal-body">

                    <div class="mb-3">
                        <label for="id_route" class="form-label fw-semibold">Ruta</label>
                        <select class="form-select border-0 shadow-sm" id="id_route" name="id_route" required>
                            <option value="" disabled selected>Selecciona una ruta</option>
                            @foreach ($rutas as $ruta)
                                <option value="{{ $ruta->id }}">{{ $ruta->nombre }}</option>
                            @endforeach
                        </select>
                        <div class="invalid-feedback">Por favor selecciona una ruta.</div>
                    </div>

                    <div class="mb-3">
                        <label for="id_driver_unit" class="form-label fw-semibold">Unidad del Conductor</label>
                        <select class="form-select border-0 shadow-sm" id="id_driver_unit" name="id_driver_unit" required>
                            <option value="" disabled selected>Selecciona una unidad</option>
                            @foreach ($conductores as $conductor)
                                <option value="{{ $conductor->id }}">{{ $conductor->nombre }}</option>
                            @endforeach
                        </select>
                        <div class="invalid-feedback">Por favor selecciona una unidad del conductor.</div>
                    </div>

                    <div class="mb-3">
                        <label for="intermediate_location_id" class="form-label fw-semibold">Ubicación Intermedia</label>
                        <select class="form-select border-0 shadow-sm" id="intermediate_location_id" name="intermediate_location_id" required>
                            <option value="" disabled selected>Selecciona una ubicación</option>
                            @foreach ($ubicaciones as $ubicacion)
                                <option value="{{ $ubicacion->id }}">{{ $ubicacion->nombre }}</option>
                            @endforeach
                        </select>
                        <div class="invalid-feedback">Por favor selecciona una ubicación intermedia.</div>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label fw-semibold">Precio</label>
                        <input type="number" step="0.01" class="form-control border-0 shadow-sm" id="price" name="price" required>
                        <div class="invalid-feedback">Por favor ingresa un precio válido.</div>
                    </div>

                </div>

                <div class="modal-footer bg-light">
                    <button type="submit" class="btn btn-primary shadow-sm fw-semibold">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</div>
