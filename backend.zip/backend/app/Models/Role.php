<?php

namespace App\Models;

use Spatie\Permission\Models\Role as SpatieRole;

class Role extends SpatieRole
{
    // Aquí puedes agregar métodos o personalizar la funcionalidad
}
